public abstract class AbstractAppender implements Appender {
	 public abstract void log(String msg);
}
