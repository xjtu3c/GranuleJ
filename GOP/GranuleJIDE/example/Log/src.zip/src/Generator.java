
public interface Generator {
	public LogItem generate();
}
