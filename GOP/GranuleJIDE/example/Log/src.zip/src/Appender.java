public interface Appender{
    public void log(String msg);
}
